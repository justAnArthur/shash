<template>
  <chat-list/>
</template>

<script setup>
import ChatList from 'components/chat-list.vue'
import Navigation from 'components/navigation.vue'
</script>

<style></style>
